<?php
// Heading
$_['heading_title']      = 'Ваши транзакции';

// Column
$_['column_date_added']  = 'Дата добавления';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Количество (%s)';

// Text
$_['text_account']       = 'Профиль';
$_['text_transaction']   = 'Ваши транзакции';
$_['text_total']         = 'Ваш текущий баланс:';
$_['text_empty']         = 'У вас нет ни одной транзакции!';