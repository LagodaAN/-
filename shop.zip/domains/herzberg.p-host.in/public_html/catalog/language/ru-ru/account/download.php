<?php
// Heading
$_['heading_title']     = 'Загрузки';

// Text
$_['text_account']      = 'Профиль';
$_['text_downloads']    = 'Загрузки';
$_['text_empty']        = 'У вас нет загруженных товаров!';

// Column
$_['column_order_id']   = '№ заказа';
$_['column_name']       = 'Имя';
$_['column_size']       = 'Размер';
$_['column_date_added'] = 'Дата добавления';