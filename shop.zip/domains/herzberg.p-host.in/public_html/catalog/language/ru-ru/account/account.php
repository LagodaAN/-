<?php
// Heading
$_['heading_title']       = 'Профиль';

// Text
$_['text_account']        = 'Профиль';
$_['text_my_account']     = 'Мой профиль';
$_['text_my_orders']      = 'Мои заказы';
$_['text_my_affiliate']   = 'Партнерский профиль';
$_['text_my_newsletter']  = 'Информационная рассылка';
$_['text_edit']           = 'Редактировать профиль';
$_['text_password']       = 'Пароль';
$_['text_address']        = 'Адресная книга';
$_['text_credit_card']    = 'Управление кредитными картами';
$_['text_wishlist']       = 'Список избранного';
$_['text_order']          = 'История заказов';
$_['text_download']       = 'Загрузки';
$_['text_reward']         = 'Бонусные баллы';
$_['text_return']         = 'Запросы на возврат';
$_['text_transaction']    = 'Транзакции';
$_['text_newsletter']     = 'Подписка на рассылку';
$_['text_recurring']      = 'Повторяющиеся платежи';
$_['text_transactions']   = 'Транзакции';
$_['text_affiliate_add']  = 'Регистрация Партнерского аккаунта';
$_['text_affiliate_edit'] = 'Редактировать Партнерский профиль';
$_['text_tracking']       = 'Персональный код Партнера';