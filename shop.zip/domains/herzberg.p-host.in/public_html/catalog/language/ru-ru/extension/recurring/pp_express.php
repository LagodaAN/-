<?php
// Text
$_['text_title']          = 'Оформление через PayPal Express';
$_['text_canceled']       = 'Платеж успешно отменен!';

// Button
$_['button_cancel']       = 'Отмена повт. платежа';

// Error
$_['error_not_cancelled'] = 'Ошибка: %s';
$_['error_not_found']     = 'Невозможно отменить профиль повторяющегося платежа';