<?php
// Heading
$_['heading_title'] = 'Использовать купон';

// Text
$_['text_coupon']   = 'Купон (%s)';
$_['text_success']  = 'Купон на скидку успешно использован!';

// Entry
$_['entry_coupon']  = 'Введите код купона';

// Error
$_['error_coupon']  = 'Код купона неверен или уже был использован ранее!';
$_['error_empty']   = 'Введите код купона!';