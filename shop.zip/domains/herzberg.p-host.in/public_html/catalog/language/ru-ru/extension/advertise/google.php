<?php

// Text
$_['text_cron_email_message'] = '<p>Это автоматический отчет о последнем выполнении CRON задачи модулем Google Shopping.</p><p>%s</p>';
$_['text_cron_email_subject'] = 'Отчет CRON - Google Shopping on OpenCart';
$_['text_per_day']            = '$%s в день';
