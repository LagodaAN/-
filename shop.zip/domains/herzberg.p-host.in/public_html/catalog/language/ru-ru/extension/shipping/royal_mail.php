<?php
// Text
$_['text_title']                 		= 'Royal Mail';
$_['text_weight']                		= 'Вес:';
$_['text_insurance']             		= 'Страховать на сумму:';
$_['text_special_delivery']      		= 'Срочная доставка на следующий день';
$_['text_1st_class_signed']      		= 'Заказная почта первого класса';
$_['text_2nd_class_signed']      		= 'Заказная почта второго класса';
$_['text_1st_class_standard']   		= 'Стандартная почта первого класса';
$_['text_2nd_class_standard']    		= 'Стандартная почта второго класса';
$_['text_international_standard']       = 'Международная стандартная';
$_['text_international_tracked_signed'] = 'Международная заказная, с отслеживанием';
$_['text_international_tracked']        = 'Международная с отслеживанием';
$_['text_international_signed']         = 'Международная заказная';
$_['text_international_economy']        = 'Международная, экономный вариант';