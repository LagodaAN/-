<?php
// Text
$_['text_title'] = 'Кредитная / дебетовая карта (Authorize.Net)';