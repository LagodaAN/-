<?php
// Text
$_['text_title']    = 'Почта Австралии';