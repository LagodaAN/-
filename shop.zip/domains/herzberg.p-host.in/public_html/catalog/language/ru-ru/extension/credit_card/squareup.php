<?php

$_['heading_title'] = 'Кредитные карты Square';

$_['text_account'] = 'Аккаунт';
$_['text_back'] = 'Назад';
$_['text_delete'] = 'Удалить';
$_['text_no_cards'] = 'Нет сохраненных карт в нашей базе данных.';
$_['text_card_ends_in'] = '%s карт заканчивается в &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; %s';
$_['text_warning_card'] = 'Вы действительно хотите удалить данную карту? Вы сможете добавить ее позднее, при следующей покупке.';
$_['text_success_card_delete'] = 'Ваша карта была успешно удалена.';