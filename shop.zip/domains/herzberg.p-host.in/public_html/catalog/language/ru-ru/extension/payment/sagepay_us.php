<?php
// Text
$_['text_title']				= 'Кредитная карта / Дебетовая карта (SagePay)';
$_['text_credit_card']			= 'Данные карты';

// Entry
$_['entry_cc_owner']			= 'Владелец карты';
$_['entry_cc_number']			= 'Номер карты';
$_['entry_cc_expire_date']		= 'Срок действия карты';
$_['entry_cc_cvv2']				= 'Секретный код карты (CVV2)';