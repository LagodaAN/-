<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Вес:';
$_['text_insurance']   = 'Страховать на сумму:';
$_['text_time']        = 'Приблизительное время: в течение 48 часов';