<?php
// Heading
$_['heading_title'] = 'Часто покупаемые';

// Text
$_['text_tax']      = 'Без налога:';