<?php
// Text
$_['text_title'] = 'Бесплатно';