<?php
// Heading
$_['heading_title'] = 'Популярные';

// Text
$_['text_tax']      = 'Без налога:';