<?php
$_['text_klarna_fee'] = 'Оплата Klarna';