<?php
// Text
$_['text_handling'] = 'Оплата за обработку';