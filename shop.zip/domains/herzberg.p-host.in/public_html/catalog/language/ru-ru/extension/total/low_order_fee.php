<?php
// Text
$_['text_low_order_fee'] = 'Оплата за минимальый заказ';