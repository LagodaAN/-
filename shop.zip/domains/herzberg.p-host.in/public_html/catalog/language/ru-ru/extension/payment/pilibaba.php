<?php
// Text
$_['text_title']        = 'Pilibaba';
$_['text_redirecting']  = 'Перенаправление...';