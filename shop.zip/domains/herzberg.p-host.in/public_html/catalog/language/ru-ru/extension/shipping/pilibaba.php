<?php
// Text
$_['text_title']       = 'PiliExpress';
$_['text_description'] = 'PiliExpress (только для оформления заказа через Pilibaba)';