<?php
// Heading
$_['heading_title']    = 'Профиль';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Войти';
$_['text_logout']      = 'Выйти';
$_['text_forgotten']   = 'Забыли пароль';
$_['text_account']     = 'Мой профиль';
$_['text_edit']        = 'Редактировать профиль';
$_['text_password']    = 'Пароль';
$_['text_address']     = 'Адресная книга';
$_['text_wishlist']    = 'Избранное';
$_['text_order']       = 'История заказов';
$_['text_download']    = 'Загрузки';
$_['text_reward']      = 'Бонусные баллы';
$_['text_return']      = 'Возвраты';
$_['text_transaction'] = 'Транзакции';
$_['text_newsletter']  = 'Рассылка';
$_['text_recurring']   = 'Повторяющиеся платежи';