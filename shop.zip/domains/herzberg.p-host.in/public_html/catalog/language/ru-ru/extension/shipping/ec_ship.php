<?php
// Text
$_['text_title']                               = 'EC-Ship';
$_['text_weight']                              = 'Вес:';
$_['text_air_registered_mail']                 = 'Письмо с треком (Авиа)';
$_['text_air_parcel']                          = 'Посылка (Авиа)';
$_['text_e_express_service_to_us']             = 'Доставка e-Express в США';
$_['text_e_express_service_to_canada']         = 'Доставка e-Express в Канаду';
$_['text_e_express_service_to_united_kingdom'] = 'Доставка e-Express в Великобританию';
$_['text_e_express_service_to_russia']         = 'Доставка e-Express в Россию';
$_['text_e_express_service_one']               = 'Доставка e-Express';
$_['text_e_express_service_two']               = 'e-Express service';
$_['text_speed_post']                          = 'SpeedPost (Standard Service)';
$_['text_smart_post']                          = 'Smart Post';
$_['text_local_courier_post']                  = 'Local Courier Post (Counter Collection)';
$_['text_local_parcel']                        = 'Local Parcel';

//error
$_['text_unavailable']                         = 'Не найдено ни одного способа доставки';
