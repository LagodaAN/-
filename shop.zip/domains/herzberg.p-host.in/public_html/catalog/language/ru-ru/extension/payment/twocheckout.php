<?php
// Text
$_['text_title'] = 'Кредитные карты / дебетовой карты (2Checkout)';