<?php
// Text
$_['text_title'] = 'Кредитная карта / Дебетовая карта  (Payza)';