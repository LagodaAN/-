<?php
// Text
$_['text_error'] = 'Страница не найдена!';