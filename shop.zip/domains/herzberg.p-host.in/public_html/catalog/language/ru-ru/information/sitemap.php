<?php
// Heading
$_['heading_title']    = 'Карта сайта';

// Text
$_['text_special']     = 'Акции';
$_['text_account']     = 'Мой профиль';
$_['text_edit']        = 'Редактировать данные';
$_['text_password']    = 'Пароль';
$_['text_address']     = 'Адреса';
$_['text_history']     = 'История заказов';
$_['text_download']    = 'Загрузки';
$_['text_cart']        = 'Корзина';
$_['text_checkout']    = 'Оформить заказ';
$_['text_search']      = 'Поиск';
$_['text_information'] = 'Информация';
$_['text_contact']     = 'Контакты';