<?php
// Text
$_['text_information']  = 'Информация';
$_['text_service']      = 'Покупателям';
$_['text_extra']        = 'Дополнительно';
$_['text_contact']      = 'Обратная связь';
$_['text_return']       = 'Возвраты';
$_['text_sitemap']      = 'Карта сайта';
$_['text_manufacturer'] = 'Бренды';
$_['text_voucher']      = 'Подарочные сертификаты';
$_['text_affiliate']    = 'Партнерская программа';
$_['text_special']      = 'Акции';
$_['text_account']      = 'Мой профиль';
$_['text_order']        = 'История заказов';
$_['text_wishlist']     = 'Избранное';
$_['text_newsletter']   = 'Подписка на новости';
$_['text_powered']      = '%s &copy; %s<br />Работает на <a href="https://www.opencart.com" target="_blank">Опенкарт</a>';