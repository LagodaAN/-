<?php
// Text
$_['text_all'] = 'Показать все';