<?php
// Text
$_['text_items']     = '%s'; 
$_['text_empty']     = 'Ваша корзина пуста!';
$_['text_cart']      = 'Просмотреть корзину';
$_['text_checkout']  = 'Оформить заказ';
$_['text_recurring'] = 'Платёжный профиль';